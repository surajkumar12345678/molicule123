<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        // return view('auth.register');
        return view('merchent.register');
    }
    /**
     * Handle an incoming registration request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $validateData=$request->validate([
            'first_name' => ['required','alpha'],
            'last_name' => ['required','alpha'],
            'email' => 'required|string|email|max:255|unique:users',
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
            'mobile_number' => ['required','numeric', 'digits:10'],
            'terms_conditions' => ['required'],
        ]);
       if ($validateData)
       {
        $user = User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'role' => "merchent",
            'password' => Hash::make($request->password),
            'mobile_number' => $request->mobile_number,
            'terms_conditions'=>$request->terms_conditions
        ]);
    }
        event(new Registered($user));

        Auth::login($user);

        return redirect('/domain_name')->with('success', 'Your registration is done.');
    }
}

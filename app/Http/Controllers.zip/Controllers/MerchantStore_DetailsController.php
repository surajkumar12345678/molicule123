<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StoreDetail;
use Illuminate\Support\Facades\Auth;

class MerchantStore_DetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */ 
    
    
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    
    
    public function domainname(Request $request)
    {
        $domain_name = $request->domain_name;
        $plan_id = $request->plan_id;
        return redirect('/store_details')->with('domain_name',$domain_name)
                                         ->with('plan_id',$plan_id);
    }

    public function planid(Request $request)
    {
        $plan_id = $request->plan_id;
        if (Auth::check())
        {
        return redirect('/domain_name')->with('plan_id',$plan_id);
        }
        else
        {
            return redirect('/register'); 
        }
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'store_name' => ['required'],
            'store_logo' => ['image','mimes:jpeg,png,jpg,gif,svg']
        ]);
        $store_logo="";
       if($request->file('store_logo'))
       {
        $store_logo= $request->file('store_logo')->getClientOriginalName();
        $request->file('store_logo')->storeAs('public/uploads/',$store_logo);
       }
        
        $plan_id = $request->plan_id;
        $domain_name = $request->domain_name;
        $store_name = $request->store_name;
        $about_store = $request->about_store;
        $user_id = Auth::id();
        return redirect('/selectlayout')->with('store_name', $store_name)
                                        ->with('store_logo',$store_logo)
                                        ->with('about_store',$about_store)
                                        ->with('plan_id',$plan_id)
                                        ->with('domain_name',$domain_name)
                                        ->with('user_id',$user_id);
                                       
        
    }

    public function layoutid(Request $request)
    {
            
            $insert = StoreDetail::create([
                'store_name' => $request->store_name,
                'store_logo' => $request->store_logo,
                'about_store' => $request->about_store,
                'domain_name' => $request->domain_name,
                'user_id' => $request->user_id,
                'plan_id' => $request->plan_id,
                'layout_id' => $request->layout_id,
            ]);
           
            if($insert)
            {
            return redirect()->back();
            }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function coverimage(Request $request)
    {
        $validatedData = $request->validate([
            'image1' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image2' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image3' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image4' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image5' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image6' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image7' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image8' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image9' => ['image','mimes:jpeg,png,jpg,gif,svg'],
            'image10' => ['image','mimes:jpeg,png,jpg,gif,svg']
        ]);
        
        return $request->input();
        
    }
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

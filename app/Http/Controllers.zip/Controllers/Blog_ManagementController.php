<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blog;
use App\Models\StoreDetail;
use Illuminate\Support\Facades\Auth;
class Blog_ManagementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $blogs= Blog::all();
        return view('merchant-dashboard.blog-management',compact('blogs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validateData= $request->validate([
            'title' => ['required','unique:blogs'], 
            'body'  => ['required'],
            'image' => ['required','image','mimes:jpeg,png,jpg,gif,svg']
        ]);
        $image= $request->file('image')->getClientOriginalName();
        $request->file('image')->storeAs('public/uploads/',$image);
        $user_id = Auth::id();
        $store_detail_id = StoreDetail::select('id')
                                      ->where('user_id', Auth::id())
                                      ->get();
        $store_id="";                              
        foreach($store_detail_id as $id)
        {
          $store_id = $id->id;
        }
        $data = Blog::create([
            'title' => $request->title,
            'body' => $request->body,
            'image' => $image,
            'user_id' => $user_id,
            'store_detail_id' => $store_id,
        ]);
        if($data)
        {
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $id = $request->id;
        $validateData= $request->validate([
            'title' => ['required','unique:categories'],
            'body'  => ['required'],
            'image' => ['required','image','mimes:jpeg,png,jpg,gif,svg']
        ]);
        $image= $request->file('image')->getClientOriginalName();
        $request->file('image')->storeAs('public/uploads/',$image);
        $data=Blog::where('id',$id)->update([
            'title' => $request->title,
            'body' => $request->body,
            'image' => $image
        ]);
        if($data)
        {
            return redirect()->back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        $id = $request->id;
        $data=Blog::where('id',$id)->delete();
        return redirect()->back();
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        $merchents=User::where('role', 'merchent')->get();
        return view('admin.index', compact('merchents'));
    }
}

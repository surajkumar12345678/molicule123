<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductAttributeValue;
use App\Models\Category;
use App\Models\StoreDetail;
use App\Models\ProductType;
use Illuminate\Support\Facades\Auth;
use DataTables;


class MerchantProduct_ManagementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
			
			$store_detail_id = StoreDetail::select('id')
							  ->where('user_id', Auth::id())
							  ->get();
			
			foreach($store_detail_id as $id)
			{
				$store_id = $id->id;
			}
			$products = Product::where('store_detail_id',$store_id)->get();
            return DataTables::of($products)
            ->editColumn('id', function ($products) {
                return $products->id;
            })
            ->editColumn('name', function ($products) {
                return $products->title;
            })	
			->editColumn('Image', function ($products) {
                return $image = '<img class="productcss" src="'.asset('storage/uploads/'.$products->feature_image).'">';
            })	
			->editColumn('Price', function ($products) {
                return $products->price;
            })	
			->editColumn('Category', function ($products) {
                return $products->category;
            })
			->editColumn('Description', function ($products) {
                return $products->description;
            })
			->editColumn('Type', function ($products) {
                return $products->product_type;
            })	
			
            ->addColumn('status', function($products){
				if($products->category_name=='1'){ 
				    $checked = "checked"; 
				}else{
					$checked = " "; 
				}
				return $status_categories = '<label class="btn btn-sm rounded white" aria-pressed="true">Active</label>';
            })
			->addColumn('action', function($products){
				if($products->product_type == "Variable product"){ 
				    $button = '<a href="/variable-product-attribute/'.$products->id.'" class="active btn btn-sm btn-primary">Add Attribute</a>'; 
				}else{
					$button = '<a href="/edit-product" class="active btn btn-sm btn-primary">Edit</a>'; 
				}
				
				
				$button .= ' <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#DeleteCategory'.$products->id.'">
                <i class="fa fa-trash" aria-hidden="true"></i></button>';	
				return $button;
            })
			
            ->escapeColumns([])	     
            ->make(true);
        }
		
		
		$categories=Category::all();
        $product_types=ProductType::all();
        $store_detail_id = StoreDetail::select('id')
                                  ->where('user_id', Auth::id())
                                  ->get();
        
        foreach($store_detail_id as $id)
        {
            $store_id = $id->id;
        }
        $products = Product::where('store_detail_id',$store_id)->get();
        return view('merchant-dashboard.product-management',compact(['products','categories','product_types']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      
        $validatedData = $request->validate([
            'title' => ['required'],
            'description' => ['required'],
            'product_type' => ['required'],
            'category' => ['required'],
            'feature_image' => ['required','mimes:jpeg,png,jpg,gif,svg'],
            'sku' => ['required'],
            ]);
   
        if ($validatedData)
        {
            $name= $request->file('feature_image')->getClientOriginalName();
            $request->file('feature_image')->storeAs('public/uploads/',$name);
            $store_detail_id = StoreDetail::select('id')
                                  ->where('user_id', Auth::id())
                                  ->get();
            foreach($store_detail_id as $id)
            {
             $store_id = $id->id;
            }
                $insert=Product::create([
                'title' =>  $request->input('title'),
                'category' => $request->input('category'),
                'product_type' => $request->input('product_type'),
                'description' => $request->input('description'),
                'feature_image' => $name,
                'sku' => $request->input('sku'),
                'price' => $request->input('price'),
                'stock' => $request->input('stock'),
                'gtin' => $request->input('gtin'),
                'price_in_currency_set' => $request->input('price_in_currency_set'),
                'product_mode' => $request->input('product_mode'),
                'digital_file' => $request->input('digital_file'),
                'shipping' => $request->input('shipping'),
                'best_seller' => $request->input('best_seller'),
                'weight' => $request->input('weight'),
                'feature_home' => $request->input('feature_home'),
                'feature_category' => $request->input('feature_category'),
                'user_id' => Auth::id(),
                'store_detail_id' => $store_id,
               ]);
              
                if($insert)
                {
                    return redirect()->back()->with('success','Product added successfully');
                }
            
         }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function variableproductattribute(Request $request,$id)
    {
       $product = Product::where('id',$id)->get();
       $attributes =ProductAttribute::all();
       return view('merchant-dashboard.variable-product-attribute',compact(['product','attributes']));
    }

    public function variableattributevalue(Request $request,$id)
    {
        $attribute_name = $request->input('attribute_name');
        $attributes_id =ProductAttribute::select('id')->where('attribute_name',$attribute_name)->get();
        foreach($attributes_id as $attributeid)
            {
             $attribute_id = $attributeid->id;
            }
        $str = $request->demo;
        $attribute_values=ProductAttributeValue::create([
            'attribute_value' => $str[0],
            'product_attribute_id' => $attribute_id,
            'product_id' => $id
        ]);

        if($attribute_values)
        {
            return redirect()->back();
        }
    }

    public function newattribute(Request $request)
    {
      $validatedData= $request->validate([
        'new_attribute' => ['required','alpha','unique:product_attributes']
      ]);
        $data = ProductAttribute::create([
        'attribute_name' => $request->input('new_attribute'),
      ]);
      if($data)
      {
        return redirect()->back(); 
      }
    }

    public function variableproductvariation(Request $request,$id)
    {
       $product = Product::where('id',$id)->get();
       $attributes =ProductAttribute::all();
       $attribute_values = ProductAttributeValue::where('product_id',$id)->get();
       return view('merchant-dashboard.variable-product-variation',compact(['product','attributes']));
    }
}
